<?php
// Mendapatkan data dari formulir
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$obat = $_POST['obat'];
$jumlah = $_POST['jumlah'];

// Harga obat per unit
$harga_obat = [
    "Paracetamol" => 5000,
    "Amoxicillin" => 8000,
    "Obat antimual" => 15000,
    "Obat kunyah" => 10000,
    "Obat antibiotik" => 12000,
    "Fasidol Forte" => 10000,
    "Dumin" => 18000,
    "Mirasic Forte" => 20000,
    "Sumagesic" => 25000,
    "Sanmol Forte" => 15000,
    "Panadol" => 5000
    // Tambahkan harga obat-obatan lainnya sesuai kebutuhan
];

// Memeriksa apakah obat tersedia di daftar
if (!array_key_exists($obat, $harga_obat)) {
    echo "Maaf, obat yang Anda pilih tidak tersedia.";
    exit;
}

// Menghitung total harga
$total_harga = $harga_obat[$obat] * $jumlah;

// Menampilkan informasi pembelian
echo "<h2>Informasi Pembelian</h2>";
echo "Nama: $nama <br>";
echo "Alamat: $alamat <br>";
echo "Obat: $obat <br>";
echo "Jumlah: $jumlah <br>";
echo "Total Harga: Rp " . number_format($total_harga, 0, ',', '.') . "<br>";

// Contoh logika untuk pemrosesan lebih lanjut seperti pengurangan stok, dll dapat ditambahkan di sini
?>
