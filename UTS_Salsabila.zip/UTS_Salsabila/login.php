<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="navbar.css">
    <link rel="shortcut icon" href="logo.png" type="image/x-icon">
    <style>
        body{
            background-image: url('bg.jpg'); 
            background-size: cover;
            background-repeat: no-repeat;
        }
        #hero {
            height: 600px;
            width: 100%; 
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-container {
            background: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .login-container h2 {
            text-align: center;
        }
        .login-container form {
            display: flex;
            flex-direction: column;
        }
        .login-container form input {
            margin-bottom: 10px;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        .login-container form button {
            padding: 8px;
            border-radius: 4px;
            border: none;
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
        }
        .login-container form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <?php
    session_start();

    if(isset($_POST['login'])){
        $username=$_POST['username'];
        $password=$_POST['password'];

        if($username== "salsabila" && $password == "123") {
            $_SESSION['login']=true;
            header("location:index.php");
            exit;
        } else {
            echo "<script>alert('Username atau Password yang anda masukkan salah!');</script>";
        }
    }
    ?>
    <center>
    <div class="container" id="hero">
    <div class="login-container">
    <h2>Login</h2>
    <form method="post">
        <input type="text" name="username" placeholder= "Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" name="login">Login</button>
    </form>
    </div>
    </div>
    </center>

   
</body>
</html>
