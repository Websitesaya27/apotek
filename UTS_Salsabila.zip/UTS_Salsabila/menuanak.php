<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Obat Anak</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            color: white;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
        }
        .add-to-cart-btn {
            padding: 5px 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            text-decoration: none;
        }
        .add-to-cart-btn:hover {
            background-color: #0056b3;
        }
        #cart {
            margin-top: 20px;
            border: 1px solid black;
            padding: 10px;
        }
        .cart-item{
            color: white;
        }
    </style>
</head>
<body>

<h2  style="color: white;">Menu Obat Anak</h2>

<table>
    <thead>
        <tr>
            <th>Nama Obat</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Data obat dalam array PHP
        $obat = array(
            array("Paracetamol", 5000, 10),
            array("Ibuprofen", 10000, 15),
            array("Obat antimual", 8000, 8),
            array("Obat kunyah", 12000, 12),
            array("Obat antibiotik", 18000, 9)
        );

        // Menampilkan data obat
        foreach ($obat as $index => $data) {
            echo "<tr>";
            echo "<td>" . $data[0] . "</td>";
            echo "<td>Rp " . number_format($data[1], 0, ',', '.') . "</td>";
            echo "<td id='stok_$index'>" . $data[2] . "</td>"; // Menambahkan ID unik untuk setiap elemen stok
            echo "<td><center><a class='add-to-cart-btn' onclick='addToCart(\"" . $data[0] . "\", " . $data[1] . ", " . $index . ")'><i class='bi bi-cart-plus-fill'></i></a></center></td>"; // Mengirimkan ID stok sebagai parameter
            echo "</tr>";
        }
        ?>
    </tbody>
</table>

<h2  style="color: white;">Keranjang Belanja</h2>
<div id="cart"></div>

</body>

<script>
    // Variabel untuk menyimpan keranjang belanja
var cart = [];

// Fungsi untuk menambahkan obat ke keranjang belanja
function addToCart(namaObat, hargaObat, indexStok) {
    var stokObat = document.getElementById('stok_' + indexStok).innerHTML;
    stokObat = parseInt(stokObat);

    // Mengecek apakah stok obat cukup
    if (stokObat <= 0) {
        alert("Maaf, stok obat habis.");
        return;
    }

    // Menambahkan obat ke dalam keranjang belanja
    cart.push({nama: namaObat, harga: hargaObat});
    // Mengurangi stok obat
    stokObat--;

    // Memperbarui tampilan stok obat
    document.getElementById('stok_' + indexStok).innerHTML = stokObat;

    // Menampilkan keranjang belanja
    displayCart();
}

// Fungsi untuk menampilkan keranjang belanja
function displayCart() {
    var cartDiv = document.getElementById('cart');
    // Mengosongkan div sebelum menambahkan kembali isi keranjang
    cartDiv.innerHTML =  "<span class='cart-item'>" + "<h3>Belanjaan</h3>";

    if (cart.length === 0) {
        cartDiv.innerHTML += "Keranjang belanja kosong.";
    } else {
        for (var i = 0; i < cart.length; i++) {
            cartDiv.innerHTML +=  "<span class='cart-item'>" + cart[i].nama + " - Rp " + cart[i].harga.toLocaleString() + "<br>";
        }
    }
}
</script>
</html>
