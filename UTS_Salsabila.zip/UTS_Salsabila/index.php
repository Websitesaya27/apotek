<!DOCTYPE html>
<html>
<head>
    <title>Home Apotik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="navbar.css">
    <link rel="shortcut icon" href="logo.png" type="image/x-icon">
    <style>
        .slider-container {
            width: 80%;
            margin: 0 auto;
            overflow: hidden;
            position: relative;
        }
        .slider {
            display: flex;
            transition: transform 0.5s ease-in-out;
        }
        .slide {
            flex: 0 0 100%;
            max-width: 100%;
        }
        .slide img {
            width: 150; 
            max-width: 100%; 
            height: 150;
        }
    </style>
</head>
<body>
    <header class="sticky-top">
    <nav class="navbar" style="background-color: #1C5362;">
    <div class="container-fluid">
      <a class="navbar-brand"><img src="logo.png" style="float:left" width="50px"><h4 class="text-light"><b><i> Apotek</i></b></h4></a>
      <ul class="nav nav-underline justify-content-end">
        <li class="nav-item">
          <a class="nav-link text-light" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="gabungan2file.php">Informasi</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="pembelian.php">Pemesanan</a>
        </li>
        </ul>
    </div>
    </nav>
    </header>

    <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="img1.jpg" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
          <img src="img2.jpg" class="d-block w-100" style="height: 500px;">
        </div>
        <!-- Pastikan Anda memiliki gambar yang valid di sini -->
      </div>
    </div>

    <div class="container-fluid p-2"  style="background-color: #1C5362;">
<h2 class="text-center text-light mt-3">Macam-Macam Obat</h2>
</div>

<div style="display: flex; flex-wrap: wrap; justify-content: center;">
    <?php
    // Array daftar gambar obat
    $gambar_obat = array(
        "Paracetamol" => array ("gambar" => "obat1.jpg", "nama" => "Paracetamol"),
        "Ibu Profen" => array ("gambar" => "obat2.jpg", "nama" => "Ibu Profen"),
        "Obat Antimual" => array ("gambar" => "obat3.jpg", "nama" => "Obat Antimual"),
        "Obat Kunyah" => array ("gambar" => "obat4.jpg", "nama" => "Obat Kunyah"),
        "Obat Antibiotik" => array ("gambar" => "obat5.jpg", "nama" => "Obat Antibiotik"),
        "Fasidol Forts" => array ("gambar" => "obat6.jpg", "nama" => "Fasidol Forte"),
        "Dumin" => array ("gambar" => "obat7.jpg", "nama" => "Dumin"),
        "Mirasic Forts" => array ("gambar" => "obat8.jpg", "nama" => "Mirasic Forte"),
        "Sumagesic" => array ("gambar" => "obat9.jpg", "nama" => "Sumagesic"),
        "Sanmol Forte" => array ("gambar" => "obat10.jpg", "nama" => "Sanmol Forte"),
        "Panadol" => array ("gambar" => "obat11.jpg", "nama" => "Panadol"),
        "Cargesik" => array ("gambar" => "obat12.jpg", "nama" => "Cargesik"),
        // Tambahkan gambar obat lainnya di sini
    );

    // Loop melalui daftar gambar obat
    foreach ($gambar_obat as $nama_obat => $gambar) {
        echo "<div style='margin: 10px;'>";
        echo "<img src='". $gambar['gambar']. "' alt=' " . $gambar['nama']." width='350' height='350'>";
        echo "<p>$nama_obat</p>";
        echo "</div>";
    }
    ?>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Script untuk slideshow gambar
    $(document).ready(function(){
        var slideCount = $('.slide').length;
        var slideWidth = $('.slide').width();
        var slideHeight = $('.slide').height();
        var sliderWidth = slideCount * slideWidth;
        $('.slider').css({ width: sliderWidth, height: slideHeight });
        
        setInterval(function() {
            $('.slider').animate({
                marginLeft: - slideWidth
            }, 1000, function () {
                $('.slider').css({marginLeft: 0}).find('.slide:first').appendTo('.slider');
            });
        }, 1000);
    });
</script>

<center><footer>
    <div class="container-fluid p-3"  style="background-color: #1C5362;">
        <p class="text-light">&copy; 2024 Apotek Sehati. All rights reserved.</p>
    </div>
    </footer></center>

</body>
</html>
