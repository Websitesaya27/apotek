// Variabel untuk menyimpan keranjang belanja
var cart = [];

// Fungsi untuk menambahkan obat ke keranjang belanja
function addToCart(namaObat, hargaObat, stokObat) {
    // Mengecek apakah stok obat cukup
    if (stokObat <= 0) {
        alert("Maaf, stok obat habis.");
        return;
    }

    // Menambahkan obat ke dalam keranjang belanja
    cart.push({nama: namaObat, harga: hargaObat});
    // Mengurangi stok obat
    stokObat--;

    // Menampilkan keranjang belanja
    displayCart();
}

// Fungsi untuk menampilkan keranjang belanja
function displayCart() {
    var cartDiv = document.getElementById('cart');
    // Mengosongkan div sebelum menambahkan kembali isi keranjang
    cartDiv.innerHTML = "<h3>Keranjang Belanja</h3>";

    if (cart.length === 0) {
        cartDiv.innerHTML += "Keranjang belanja kosong.";
    } else {
        for (var i = 0; i < cart.length; i++) {
            cartDiv.innerHTML += cart[i].nama + " - Rp " + cart[i].harga.toLocaleString() + "<br>";
        }
    }
}
