<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>informasi</title>
</head>
<body>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informasi Apotek</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            color: white;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
        
    </style>
</head>
<body>

<?php
// Informasi apotek
$apotek = array(
    array("Nama Apotek", "Alamat", "Nomor Telepon"),
    array("Apotek Sehati", "Jl. Cemara No. 123,Tambun Selatan", "(021) 1234567"),
    array("Apotek Sehati", "Jl. Mangga No. 45,Bekasi Timur", "(021) 7654321"),
    array("Apotek Sehati", "Jl. Anggrek No. 78,Jatiasih ", "(021) 9876543")
);
?>

<h2 style="color: white;">Informasi Apotek</h2>
<table>
    <?php foreach ($apotek as $row): ?>
        <tr>
            <?php foreach ($row as $cell): ?>
                <td><?php echo $cell; ?></td>
            <?php endforeach; ?>
        </tr>
    <?php endforeach; ?>
</table>

</body>
</html>

</body>
</html>