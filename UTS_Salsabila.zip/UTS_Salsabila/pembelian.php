<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pembelian Obat</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="navbar.css">
<link rel="shortcut icon" href="logo.png" type="image/x-icon">
<style>
    .form-container {
    width: 400px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.form-container h2 {
    margin-bottom: 20px;
}

.form-container label {
    display: block;
    margin-bottom: 10px;
}

.form-container input[type="text"],
.form-container input[type="email"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.form-container input[type="submit"] {
    background-color: #007bff;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.form-container input[type="submit"]:hover {
    background-color: #0056b3;
}
</style>

</head>
<body>
<header>
    <nav class="navbar sticky-top"  style="background-color: #1C5362;">
    <div class="container-fluid">
    <a class="navbar-brand"><img src="logo.png" style="float:left" width="50px"><h4 class="text-light"><b><i> Apotek</i></b></h4></a>
      <ul class="nav nav-underline justify-content-end">
        <li class="nav-item">
          <a class="nav-link text-light" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="gabungan2file.php">Informasi</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="pembelian.php">Pemesanan</a>
        </li>
        </ul>
    </div>
    </nav>
    </header>

<div class="form-container mt-5">
<h4>Form Pembelian Obat</h4>
<form action="proses_pembelian.php" method="post">
    <label for="nama">Nama:</label>
    <input type="text" id="nama" name="nama" required><br>

    <label for="alamat">Alamat:</label>
    <input type="text" id="alamat" name="alamat" required><br>


    <label for="obat">Pilih Obat:</label>
    <select id="obat" name="obat" required>
        <option value="">pilih obat</option>
        <option value="Paracetamol">Paracetamol</option>
        <option value="Ibuprofen">Ibuprofen</option>
        <option value="Obat antimual">Obat antimual</option>
        <option value="Obat kunyah">Obat kunyah</option>
        <option value="Obat antibiotik">Obat antibiotik</option>
        <option value="Fasidol Forte">Fasidol Forte</option>
        <option value="Dumin">Dumin</option>
        <option value="Mirasic Forte">Mirasic Forte</option>
        <option value="Sumagesic">Sumagesic</option>
        <option value="Sanmol Forte">Sanmol Forte</option>
        <option value="Panadol">Panadol</option>
        <!-- Tambahkan obat-obatan lainnya sesuai kebutuhan -->
    </select><br><br>

    <label for="jumlah">Jumlah:</label>
    <input type="number" id="jumlah" name="jumlah" min="1" required><br><br>

    <button type="submit" class="btn btn-primary">Beli</button>
</form>
</div>

<center><footer>
    <div class="container-fluid mt-3 p-3"  style="background-color: #1C5362;">
        <p class="text-light">&copy; 2024 Apotek Sehati. All rights reserved.</p>
    </div>
    </footer></center>

</body>
</html>
