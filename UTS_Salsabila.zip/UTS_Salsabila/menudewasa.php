<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Obat Dewasa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            color: white;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
        }
        
        .add-to-cart-btn {
            padding: 5px 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        .add-to-cart-btn:hover {
            background-color: #0056b3;
        }
        #cart {
            margin-top: 20px;
            border: 1px solid black;
            padding: 10px;
        }
        .cart-item {
            color: white;
        }
    </style>
</head>
<body>

<h2 style="color: white;">Menu Obat Dewasa</h2>

<table>
    <thead>
        <tr>
            <th>Nama Obat</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Data obat dalam array PHP
        $obat = array(
            array("Paracetamol", 5000, 10),
            array("Fasidol Forte", 8000, 15),
            array("Dumin", 9000, 8),
            array("Mirasic Forte ", 12000, 12),
            array("Sumagesic", 12000, 12),
            array("Sanmol Forte", 5000, 15),
            array("Panadol ", 15000, 12),
        );

        // Menampilkan data obat
        foreach ($obat as $data) {
            echo "<tr>";
            echo "<td>" . $data[0] . "</td>";
            echo "<td>Rp " . number_format($data[1], 0, ',', '.') . "</td>";
            echo "<td id='stok_" . str_replace(' ', '_', $data[0]) . "'>" . $data[2] . "</td>";
            echo "<td><center><button class='add-to-cart-btn' onclick='addToCart(\"" . $data[0] . "\", " . $data[1] . ", \"" . str_replace(' ', '_', $data[0]) . "\")'><i class='bi bi-cart-plus-fill'></i></button></center></td>";
            echo "</tr>";
        }
        ?>
    </tbody>
</table>

<h2 style="color: white;">Keranjang Belanja</h2>
<div id="cart"></div>

</body>

<script>
    // Variabel untuk menyimpan keranjang belanja
var cart = [];

// Fungsi untuk menambahkan obat ke keranjang belanja
function addToCart(namaObat, hargaObat, idStok) {
    var stokObat = document.getElementById('stok_' + idStok).innerHTML;
    stokObat = parseInt(stokObat);

    // Mengecek apakah stok obat cukup
    if (stokObat <= 0) {
        alert("Maaf, stok obat habis.");
        return;
    }

    // Menambahkan obat ke dalam keranjang belanja
    cart.push({nama: namaObat, harga: hargaObat});
    // Mengurangi stok obat
    stokObat--;

    // Memperbarui tampilan stok obat
    document.getElementById('stok_' + idStok).innerHTML = stokObat;

    // Menampilkan keranjang belanja
    displayCart();
}

// Fungsi untuk menampilkan keranjang belanja
function displayCart() {
    var cartDiv = document.getElementById('cart');
    // Mengosongkan div sebelum menambahkan kembali isi keranjang
    cartDiv.innerHTML = "<span class='cart-item'>" +"<h3>Belanjaan</h3>";

    if (cart.length === 0) {
        cartDiv.innerHTML += "Keranjang belanja kosong.";
    } else {
        for (var i = 0; i < cart.length; i++) {
            cartDiv.innerHTML += "<span class='cart-item'>" + cart[i].nama + " - Rp " + cart[i].harga.toLocaleString() + "<br>";
        }
    }
}
</script>
</html>
