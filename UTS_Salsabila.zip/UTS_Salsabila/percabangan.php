<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Tugas 5</title>
</head>
<body>
<div class="container pt-5" style="width:400px;">
<div class="card">
    <center><h4 class="card-header">menuju menu</h4></center>
    <?php
// Fungsi untuk menghitung umur berdasarkan tanggal lahir
function hitungUmur($tanggal_lahir) {
    $tanggal_lahir = new DateTime($tanggal_lahir);
    $today = new DateTime('today');
    $umur = $tanggal_lahir->diff($today)->y;
    return $umur;
}

// Proses form jika tombol submit ditekan
if(isset($_POST['submit'])){
    // Ambil tanggal lahir dari input
    $tanggal_lahir = $_POST['tanggal_lahir'];

    // Hitung umur
    $umur = hitungUmur($tanggal_lahir);

    // Periksa umur dan arahkan ke menu obat yang sesuai
    if($umur < 17){
        // Di bawah 17 tahun, arahkan ke menu obat untuk di bawah umur
        header("Location: menuanak.php");
        exit();
    } else {
        // Di atas atau sama dengan 17 tahun, arahkan ke menu obat untuk di atas umur
        header("Location: menudewasa.php");
        exit();
    }
}
?>

<!-- Form untuk memasukkan tanggal lahir -->
<form method="post" action=""><br><center>
    <input type="text" name="tanggal_lahir" placeholder="YYYY-MM-DD" required><br><br>
    <input type="submit" name="submit" value="Cek Umur" class="btn btn-primary" required><br><br><br>
</form>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
