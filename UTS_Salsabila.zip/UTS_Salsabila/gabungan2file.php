<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="navbar.css">
    <link rel="shortcut icon" href="logo.png" type="image/x-icon">
    <style>
        .frame {
            width: 50%;
            float: left;
            height: 100vh;
            border: none;   
        }
      
    </style>
</head>
<body>
<header>
    <nav class="navbar sticky-top "  style="background-color: #1C5362;">
    <div class="container-fluid ">
    <a class="navbar-brand"><img src="logo.png" style="float:left" width="50px"><h4 class="text-light"><b><i> Apotek</i></b></h4></a>
      <ul class="nav nav-underline justify-content-end">
        <li class="nav-item">
          <a class="nav-link text-light" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="gabungan2file.php">Informasi</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="pembelian.php">Pemesanan</a>
        </li>
        </ul>
    </div>
    </nav>
    </header>
    
    <iframe src="perulangan.php" class="frame"></iframe>
    <iframe src="percabangan.php" class="frame"></iframe>

    <center><footer>
    <div class="container-fluid p-3"  style="background-color: #1C5362;">
        <p class="text-light">&copy; 2024 Apotek Sehati. All rights reserved.</p>
    </div>
    </footer></center>

</body>
</html>
